import styles from "./Login.module.css";
import {useState} from "react";
import {erro, sucesso} from "../../utils/toast";
import {useRouter} from "next/router";
import {login} from "@/src/pages/api/loginService";
import {ToastContainer} from "react-toastify";


export default function Login() {

    const[nif, setNif] = useState<string>('');
    const[senha, setSenha] = useState<string>('');

    const router = useRouter();

    async function logar (e: React.FormEvent<HTMLFormElement>){
        e.preventDefault();
        try {
            const response = await login(nif, senha)
            sucesso('Login realizado com sucesso');
            setTimeout(() => {
                router.push('/listaPatrimoniosPorSala');
            })
        }
        catch {
            erro('nif ou senha invalidos');
        }
    }

    return (
        <>
            <ToastContainer></ToastContainer>
        <main className={styles.login_page}>
            <section
                className={styles.login_banner}
                aria-label="Apresentação do sistema"
            >
                <img
                    src="/imgs/Imagem%20do%20login.png"
                    alt="Imagem de fundo relacionada à tecnologia"
                    className={styles.banner_image}

                />

                <div className={styles.banner_overlay}></div>

                <div className={styles.banner_content}>
                    <img
                        src="/imgs/Logo%20Senai.png"
                        alt="Logo do SENAI"
                        className={styles.senai_logo}
                    />

                    <h2>Gestão de patrimônios</h2>

                    <p className={styles.banner_content_text}>
                        Controle, organização e transparência do patrimônio com eficiência.
                    </p>
                </div>
            </section>

            <section
                className={styles.login_area}
                aria-label="Formulário de login"
            >
                <form className={styles.login_form} onSubmit={logar}>
                    <h1>Login</h1>

                    <div className={styles.form_group}>
                        <label htmlFor="nif">NIF:</label>

                        <input
                            type="text"
                            id="nif"
                            name="nif"
                            placeholder="Insira o seu NIF"
                            required
                            onChange={ e => setNif(e.target.value) }
                            value={nif}
                        />
                    </div>

                    <div className={styles.form_group}>
                        <label htmlFor="senha">Senha:</label>

                        <div className={styles.password_field}>
                            <input
                                type="password"
                                id="senha"
                                name="senha"
                                placeholder="Insira a sua senha"
                                required
                                onChange={ e => setSenha(e.target.value) }
                                value={senha}
                            />

                            <button
                                type="button"
                                className={styles.show_password}
                                aria-label="Mostrar senha"
                            >
                                👁
                            </button>
                        </div>
                    </div>

                    <button
                        type="submit"
                        className={styles.login_button}
                    >
                        Entrar
                    </button>
                </form>
            </section>
        </main>
        </>
    );
}