import styles from "./detalhePatrimonio.module.css";
import Header from "@/src/Components/Header/Header";
import DescricaoPatrimonio from "@/src/Components/detalhePatrimonio/DescricaoPatrimonio/DescricaoPatrimonio";
import HistoricoPatrimonio from "@/src/Components/detalhePatrimonio/HistoricoPatrimonio/HistoricoPatrimonio";

export default function DetelhePatrimonio() {
return (
<>

    <Header></Header>

<main className={styles.page_content}>

    <DescricaoPatrimonio></DescricaoPatrimonio>
    <HistoricoPatrimonio></HistoricoPatrimonio>

</main>
</>
);
}