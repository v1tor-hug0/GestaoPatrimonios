import {api} from "@/src/pages/api/api";

export async function getPatrimonios() {
    try {
        const response = await api.get("/Patrimonio");
        return response.data;
    } catch (error: any) {
        throw new Error("Erro ao buscar patrimonios");
    }
}


export async function getPatrimonioID(patrimonioID: string) {
    try {
        const response = await api.get("/Patrimonio/" + patrimonioID);
        return response.data;
    } catch (error: any) {
        throw new Error("Erro ao buscar patrimonio");
    }

}
