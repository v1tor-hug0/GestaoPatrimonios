import {api} from "./api"
import secureLocalStorage from "react-secure-storage";
import { jwtDecode } from "jwt-decode";
import {erro} from "@/src/utils/toast";

type TokenPayload  = {
    NIF: string;
}

export async function getToken() {
    const token = secureLocalStorage.getItem("token");
    return token;
}

export async function login(nif: string, senha: string) {
    try {
        const response = await api.post("/Autenticacao/login", {nif, senha});
        const token = response.data.token;
        secureLocalStorage.setItem("token", token);
        const decodedToken = jwtDecode<TokenPayload>(token);
        console.log(decodedToken.NIF);
    }
    catch {
        erro("nif ou senha invalidos");
        return null;
    }
}