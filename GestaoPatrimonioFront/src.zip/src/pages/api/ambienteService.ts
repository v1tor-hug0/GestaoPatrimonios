import { api } from "./api"

export async function getAmbientes() {
    try {
    const response = await api.get("/Localizacao")
    return response.data
    }
    catch(error: any) {
        throw new Error("Erro ao buscar ambientes");
    }
}