
import styles from "./listaPatrimoniosPorSala.module.css";
import Header from "@/src/Components/Header/Header";
import ListaPatrimonioSalaTable from "@/src/Components/ListaPatrimonioSala/ListaPatrimonioSalaTable/ListaPatrimonioSala";
import { useParams } from "next/navigation";

// 466c5c38-da27-48df-bd47-00862e8f4bc5


export default function ListaPatrimoniosPorSala() {

    const params = useParams()
    const id = params?.id

    return (
        <>
            <Header></Header>

            <main className={styles.page_content}>
                <section
                    className={`${styles.page_header} ${styles.layout_guide}`}
                    aria-labelledby="titulo-patrimonios"
                >
                    <h1 id="titulo-patrimonios">
                        Patrimônios: Sala 09/10
                    </h1>

                    <form
                        className={styles.search_area}
                        role="search"
                    >
                        <label
                            htmlFor="pesquisa-ambiente"
                            className={styles.sr_only}
                        >
                            Pesquisar patrimônios
                        </label>

                        <input
                            type="search"
                            id="pesquisa-ambiente"
                            name="pesquisaAmbiente"
                            placeholder="Pesquise o ambiente"
                        />

                        <button
                            type="button"
                            className={styles.filter_button}
                            aria-label="Filtrar patrimonios"
                        >
                            <img src="/imgs/sliders.svg" alt=""/>
                        </button>
                    </form>
                </section>

                <ListaPatrimonioSalaTable
                localizacaoID={String(id)}
                ></ListaPatrimonioSalaTable>

                <nav
                    className={styles.pagination}
                    aria-label="Paginação"
                >
                    <button
                        type="button"
                        className={styles.pagination_button}
                        aria-label="Página anterior"
                    >
                        ‹
                    </button>

                    <a
                        href="#"
                        className={`${styles.pagination_link} ${styles.current}`}
                        aria-current="page"
                    >
                        1
                    </a>

                    <a
                        href="#"
                        className={styles.pagination_link}
                    >
                        2
                    </a>

                    <a
                        href="#"
                        className={styles.pagination_link}
                    >
                        3
                    </a>

                    <button
                        type="button"
                        className={styles.pagination_button}
                        aria-label="Próxima página"
                    >
                        ›
                    </button>
                </nav>
            </main>
        </>
    );
}