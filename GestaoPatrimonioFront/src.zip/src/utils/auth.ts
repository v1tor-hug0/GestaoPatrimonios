import secureLocalStorage from "react-secure-storage";

export function verificarAutenticacao() {
    const token = secureLocalStorage.getItem("token");

    return !!token;

    //token vira booleano e se ele existir retorna true senao retorna false. Praticamente um IF
}