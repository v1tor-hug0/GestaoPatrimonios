import { toast } from "react-toastify";

export const erro = (msg: string) => toast.error(msg);
export const sucesso = (msg: string) => toast.success(msg);