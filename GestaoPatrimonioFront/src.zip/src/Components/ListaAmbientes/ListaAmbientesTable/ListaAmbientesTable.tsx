import styles from './ListaAmbientesTable.module.css'
import ListaAmbientesRow from "@/src/Components/ListaAmbientes/ListaAmbientesRow/ListaAmbientesRow";
import {getAmbientes} from "@/src/pages/api/ambienteService";
import {useEffect, useState} from "react";

interface Ambiente {
    localizacaoID: string
    nomeLocal: string;
    responsavel: string;
    nomeArea: string;
}


const ListaAmbientesTable = () => {

    const [ambientes, setAmbientes] = useState<Ambiente[]>([]);

    async function listarAmbientes() {
        try {
            const lista = await getAmbientes()
            setAmbientes(lista);
            return lista;
        } catch (error) {
            console.log(error)
        }
    }


    useEffect(() => {
        listarAmbientes();
    }, [])

    return (
        <>
            <section
                className={`${styles.table_section} ${styles.layout_guide}`}
                aria-label="Lista de ambientes"
            >
                <table className={styles.environment_table}>
                    <thead>
                    <tr>
                        <th>Local</th>
                        <th>Responsável</th>
                        <th>Área</th>
                        <th>Detalhes</th>
                    </tr>
                    </thead>

                    {ambientes.map((item) =>
                        (<ListaAmbientesRow
                            localizacaoID={ item.localizacaoID}
                            nomeArea={ item.nomeArea}
                            nomeLocal={ item.nomeLocal}
                            responsavel={ item.responsavel}
                            key={item.localizacaoID}
                        ></ListaAmbientesRow>)
                    )}


                </table>
            </section>
        </>
    )

}
export default ListaAmbientesTable;