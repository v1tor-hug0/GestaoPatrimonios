import styles from './ListaAmbientesRow.module.css'
import Link from "next/link";

type ListaAmbientesRowProps = {
    localizacaoID: string
    nomeLocal: string
    responsavel: string
    nomeArea: string
}

const ListaAmbientesRow = ({localizacaoID ,nomeLocal, responsavel, nomeArea} : ListaAmbientesRowProps) => {
    return (
            <>
                <tbody className={styles.tablebody}>
                <tr>
                    <Link href={"/ListaPatrimonioSala/" + localizacaoID}>
                        <td>{nomeLocal}</td>
                    </Link>


                    <td>{responsavel}</td>

                    <td>{nomeArea}</td>

                    <td>
                        <a
                            href="#"
                            aria-label="Ver detalhes da Sala 30/31"
                        >
                            <img src="/imgs/info.svg" alt=""/>
                        </a>
                    </td>
                </tr>
                </tbody>
            </>
        )

}

export default ListaAmbientesRow;