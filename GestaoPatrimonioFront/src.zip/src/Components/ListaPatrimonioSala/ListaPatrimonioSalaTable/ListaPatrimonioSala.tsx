"use client";
import styles from './listaPatrimonioSala.module.css';
import ListaPatrimonioSalaRow from "@/src/Components/ListaPatrimonioSala/ListaPatrimonioSalaRow/ListaPatrimonioSalaRow";
import {useEffect, useState} from "react";
import {getPatrimonioID, getPatrimonios} from "@/src/pages/api/patrimonioService";
import {erro} from "@/src/utils/toast";

type localizacaoPatrimonio = {
    localizacaoID: string;
}

type ListaPatrimonioSala = {
    patrimonioID: string;
    numeroPatrimonio: string;
    denominacao: string;
    dataTransferencia: string;
    localizacaoID: string;
}

const ListaPatrimonioSalaTable = ({localizacaoID} : localizacaoPatrimonio) => {

    const [patrimonio, setPatrimonio] = useState<ListaPatrimonioSala[]>([]);


    async function listarPatrimonios() {
        try {
            const dados: ListaPatrimonioSala[] = await getPatrimonios()
            const lista = dados.filter((item) => item.localizacaoID === localizacaoID);
            setPatrimonio(lista);
        }
        catch (error: any) {
            erro(error.message)
        }

    }

    useEffect(() => {
        if(!localizacaoID) return;

        setTimeout(() => {
            listarPatrimonios();
        }, 500)
    }, [localizacaoID]);

    return (
            <>
                <section
                    className={`${styles.table_section} ${styles.layout_guide}`}
                    aria-label="Lista de patrimonios"
                >
                    <table className={styles.environment_table}>
                        <thead>
                        <tr>
                            <th>Patrimônio</th>
                            <th>Denominação</th>
                            <th>Data transfêrencia</th>
                            <th>Detalhes</th>
                            <th>Transferir</th>
                        </tr>
                        </thead>
                        {patrimonio.map((item) => (
                            <ListaPatrimonioSalaRow
                                patrimonioID={item.patrimonioID}
                                numeroPatrimonio={item.numeroPatrimonio}
                                dataTransferencia={item.dataTransferencia}
                                denominacao={item.denominacao}
                                key={item.patrimonioID}
                            ></ListaPatrimonioSalaRow>
                        ))}


                    </table>
                </section>



            </>
        )
}
export default ListaPatrimonioSalaTable;