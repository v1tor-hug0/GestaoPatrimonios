import styles from './ListaPatrimonioSalaRow.module.css'
import Link from "next/link";

type ListaPatrimonioSalaRowProps = {
    patrimonioID: string
    denominacao: string
    dataTransferencia: string
    numeroPatrimonio: string
}

const ListaPatrimonioSalaRow = ({patrimonioID ,dataTransferencia ,denominacao, numeroPatrimonio}: ListaPatrimonioSalaRowProps) => {



    return (


        <tbody className={styles.tablebody}>
        <tr className={styles.tablerow}>
            <td>{numeroPatrimonio}</td>
            <td>{denominacao}</td>
            <td>{dataTransferencia}</td>

            <td>
                <Link className={styles.link}
                    href="#"
                    aria-label="Ver detalhes do patrimonio"
                >
                    <img src="/imgs/info.svg" alt=""/>
                </Link>
            </td>

            <td>
                <Link className={styles.link}
                    href="#"
                    aria-label="Transferir patrimonio"
                >
                    <img src="/imgs/edit.svg" alt=""/>
                </Link>
            </td>
        </tr>
        </tbody>
    )
}
export default ListaPatrimonioSalaRow;