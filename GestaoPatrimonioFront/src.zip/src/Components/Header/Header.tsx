import styles from "./header.module.css"
import {useEffect, useState} from "react";
import {decodeToken} from "@/src/utils/decoded";
import Link from "next/link";

type Usuario = {
    id: string;
     name: string;
     email: string;
    NIF: string;
}

const Header = () => {

    const [usuario, setUsuario] = useState<Usuario>();

    async function getUserSettings() {
        const userInfos = await decodeToken();

        setUsuario(userInfos);
    }

    useEffect(
        () => {
            getUserSettings()
        }, [])


    return (
        <>

        <header className={styles.topbar}>
            <nav
                className={`${styles.navbar} ${styles.layout_guide}`}
                aria-label="Menu principal"
            >
                <a
                    href="#"
                    className={styles.logo_link}
                    aria-label="Página inicial"
                >
                    <img
                        src="/imgs/Logo%20Senai.png"
                        alt="Logo SENAI"
                        className={styles.logo}
                    />
                </a>

                <ul className={styles.menu_list}>
                    <li>
                        <a href="#" className={styles.menu_link}>
                            Ambientes
                            <img src="/imgs/chevron-down.png" alt="" style={{marginLeft: '5px', width: '15px'}}/>
                        </a>
                    </li>
                    <li>
                        <a href="#" className={styles.menu_link}>
                            Responsavel
                        </a>
                    </li>

                    <li>
                        <Link href="#" className={styles.menu_link}>
                            Patrimônios
                        </Link>
                    </li>
                </ul>

                <section
                    className={styles.user_area}
                    aria-label="Informações do usuário"
                >
                    <button
                        className={styles.user_icon}
                        aria-label="Abrir perfil do usuário"
                    >
                        <i className="fa-solid fa-user"></i>
                    </button>

                    <div className={styles.user_info}>
                        <strong>{usuario?.name}</strong>
                        <span>{usuario?.email}</span>
                    </div>

                    <button
                        className={styles.arrow_button}
                        aria-label="Abrir opções da conta"
                        style={{background: 'transparent',
                                border: 'none'}}
                    >
                        <img src="/imgs/chevron-down.png" alt=""/>
                    </button>
                </section>

                <button
                    className={styles.hamburguer}
                    aria-label="Abrir opções de menu"
                >
                    <i className="fa-solid fa-bars"></i>
                </button>
            </nav>
        </header>
        </>
    )
}

export default Header